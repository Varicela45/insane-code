﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RadixSort
{
    class Alumno
    {
        //Atributos   
        private int _intClave;
        private string _strNombre;
        private double _dblPromedio;

        //Propiedades
        public int Clave { get; set; }
        public string Nombre { get; set; }
        public double Promedio { get; set; }

        public delegate int AtributoComparable(Alumno primerAlumno, Alumno segundoAlumno);

        public static int OrdenarPorClave(Alumno primerAlumno, Alumno segundoAlumno)
        {
            return primerAlumno.Clave.CompareTo(segundoAlumno.Clave);
        }
        public static int OrdenarPorNombre(Alumno primerAlumno, Alumno segundoAlumno)
        {
            return primerAlumno.Nombre.CompareTo(segundoAlumno.Nombre);
        }
        public static int OrdenarPorPromedio(Alumno primerAlumno, Alumno segundoAlumno)
        {
            if (primerAlumno.Promedio > segundoAlumno.Promedio)
            {
                return (1);
            }
            else if (primerAlumno.Promedio < segundoAlumno.Promedio)
            {
                return (-1);
            }
            else
            {
                return (0);
            }
        }
    }
}