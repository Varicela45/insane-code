﻿namespace RadixSort
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtgAlumno = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGenerar = new System.Windows.Forms.Button();
            this.gpbOrden = new System.Windows.Forms.GroupBox();
            this.radPromedio = new System.Windows.Forms.RadioButton();
            this.radNombre = new System.Windows.Forms.RadioButton();
            this.radClave = new System.Windows.Forms.RadioButton();
            this.gpbCriterio = new System.Windows.Forms.GroupBox();
            this.radDescendente = new System.Windows.Forms.RadioButton();
            this.radAscendente = new System.Windows.Forms.RadioButton();
            this.btnOrdenar = new System.Windows.Forms.Button();
            this.lblCantidadDatos = new System.Windows.Forms.Label();
            this.lblDatosGenerados = new System.Windows.Forms.Label();
            this.dtgAlumnoOrdenado = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSalir = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgAlumno)).BeginInit();
            this.gpbOrden.SuspendLayout();
            this.gpbCriterio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgAlumnoOrdenado)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(284, 36);
            this.txtCantidad.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(119, 35);
            this.txtCantidad.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(9, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cantidad de Datos:";
            // 
            // dtgAlumno
            // 
            this.dtgAlumno.AllowUserToAddRows = false;
            this.dtgAlumno.AllowUserToDeleteRows = false;
            this.dtgAlumno.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgAlumno.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dtgAlumno.Location = new System.Drawing.Point(9, 117);
            this.dtgAlumno.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.dtgAlumno.Name = "dtgAlumno";
            this.dtgAlumno.ReadOnly = true;
            this.dtgAlumno.RowTemplate.Height = 25;
            this.dtgAlumno.Size = new System.Drawing.Size(394, 587);
            this.dtgAlumno.TabIndex = 2;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Clave";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Nombre";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Promedio";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // btnGenerar
            // 
            this.btnGenerar.Location = new System.Drawing.Point(416, 23);
            this.btnGenerar.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnGenerar.Name = "btnGenerar";
            this.btnGenerar.Size = new System.Drawing.Size(181, 65);
            this.btnGenerar.TabIndex = 3;
            this.btnGenerar.Text = "Generar";
            this.btnGenerar.UseVisualStyleBackColor = true;
            this.btnGenerar.Click += new System.EventHandler(this.btnGenerar_Click);
            // 
            // gpbOrden
            // 
            this.gpbOrden.Controls.Add(this.radPromedio);
            this.gpbOrden.Controls.Add(this.radNombre);
            this.gpbOrden.Controls.Add(this.radClave);
            this.gpbOrden.Location = new System.Drawing.Point(472, 357);
            this.gpbOrden.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.gpbOrden.Name = "gpbOrden";
            this.gpbOrden.Padding = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.gpbOrden.Size = new System.Drawing.Size(240, 269);
            this.gpbOrden.TabIndex = 4;
            this.gpbOrden.TabStop = false;
            this.gpbOrden.Text = "Ordenar por:";
            // 
            // radPromedio
            // 
            this.radPromedio.AutoSize = true;
            this.radPromedio.Location = new System.Drawing.Point(17, 196);
            this.radPromedio.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.radPromedio.Name = "radPromedio";
            this.radPromedio.Size = new System.Drawing.Size(120, 34);
            this.radPromedio.TabIndex = 2;
            this.radPromedio.Text = "Promedio";
            this.radPromedio.UseVisualStyleBackColor = true;
            // 
            // radNombre
            // 
            this.radNombre.AutoSize = true;
            this.radNombre.Location = new System.Drawing.Point(19, 130);
            this.radNombre.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.radNombre.Name = "radNombre";
            this.radNombre.Size = new System.Drawing.Size(107, 34);
            this.radNombre.TabIndex = 1;
            this.radNombre.Text = "Nombre";
            this.radNombre.UseVisualStyleBackColor = true;
            // 
            // radClave
            // 
            this.radClave.AutoSize = true;
            this.radClave.Checked = true;
            this.radClave.Location = new System.Drawing.Point(19, 68);
            this.radClave.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.radClave.Name = "radClave";
            this.radClave.Size = new System.Drawing.Size(81, 34);
            this.radClave.TabIndex = 0;
            this.radClave.TabStop = true;
            this.radClave.Text = "Clave";
            this.radClave.UseVisualStyleBackColor = true;
            // 
            // gpbCriterio
            // 
            this.gpbCriterio.Controls.Add(this.radDescendente);
            this.gpbCriterio.Controls.Add(this.radAscendente);
            this.gpbCriterio.Location = new System.Drawing.Point(472, 117);
            this.gpbCriterio.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.gpbCriterio.Name = "gpbCriterio";
            this.gpbCriterio.Padding = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.gpbCriterio.Size = new System.Drawing.Size(240, 200);
            this.gpbCriterio.TabIndex = 5;
            this.gpbCriterio.TabStop = false;
            this.gpbCriterio.Text = "Criterio de Ordenamiento";
            // 
            // radDescendente
            // 
            this.radDescendente.AutoSize = true;
            this.radDescendente.Location = new System.Drawing.Point(20, 144);
            this.radDescendente.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.radDescendente.Name = "radDescendente";
            this.radDescendente.Size = new System.Drawing.Size(152, 34);
            this.radDescendente.TabIndex = 1;
            this.radDescendente.Text = "Descendente";
            this.radDescendente.UseVisualStyleBackColor = true;
            // 
            // radAscendente
            // 
            this.radAscendente.AutoSize = true;
            this.radAscendente.Checked = true;
            this.radAscendente.Location = new System.Drawing.Point(23, 82);
            this.radAscendente.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.radAscendente.Name = "radAscendente";
            this.radAscendente.Size = new System.Drawing.Size(140, 34);
            this.radAscendente.TabIndex = 0;
            this.radAscendente.TabStop = true;
            this.radAscendente.Text = "Ascendente";
            this.radAscendente.UseVisualStyleBackColor = true;
            // 
            // btnOrdenar
            // 
            this.btnOrdenar.Location = new System.Drawing.Point(472, 636);
            this.btnOrdenar.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnOrdenar.Name = "btnOrdenar";
            this.btnOrdenar.Size = new System.Drawing.Size(240, 68);
            this.btnOrdenar.TabIndex = 6;
            this.btnOrdenar.Text = "Ordenar";
            this.btnOrdenar.UseVisualStyleBackColor = true;
            this.btnOrdenar.Click += new System.EventHandler(this.btnOrdenar_Click);
            // 
            // lblCantidadDatos
            // 
            this.lblCantidadDatos.AutoSize = true;
            this.lblCantidadDatos.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCantidadDatos.Location = new System.Drawing.Point(750, 53);
            this.lblCantidadDatos.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCantidadDatos.Name = "lblCantidadDatos";
            this.lblCantidadDatos.Size = new System.Drawing.Size(15, 17);
            this.lblCantidadDatos.TabIndex = 7;
            this.lblCantidadDatos.Text = "0";
            // 
            // lblDatosGenerados
            // 
            this.lblDatosGenerados.AutoSize = true;
            this.lblDatosGenerados.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblDatosGenerados.Location = new System.Drawing.Point(677, 9);
            this.lblDatosGenerados.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDatosGenerados.Name = "lblDatosGenerados";
            this.lblDatosGenerados.Size = new System.Drawing.Size(154, 21);
            this.lblDatosGenerados.TabIndex = 8;
            this.lblDatosGenerados.Text = "Cantidad de Datos:";
            // 
            // dtgAlumnoOrdenado
            // 
            this.dtgAlumnoOrdenado.AllowUserToAddRows = false;
            this.dtgAlumnoOrdenado.AllowUserToDeleteRows = false;
            this.dtgAlumnoOrdenado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgAlumnoOrdenado.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dtgAlumnoOrdenado.Location = new System.Drawing.Point(772, 117);
            this.dtgAlumnoOrdenado.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.dtgAlumnoOrdenado.Name = "dtgAlumnoOrdenado";
            this.dtgAlumnoOrdenado.ReadOnly = true;
            this.dtgAlumnoOrdenado.RowTemplate.Height = 25;
            this.dtgAlumnoOrdenado.Size = new System.Drawing.Size(386, 587);
            this.dtgAlumnoOrdenado.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Clave";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Nombre";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Promedio";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(1184, 30);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(174, 41);
            this.btnSalir.TabIndex = 10;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.dtgAlumnoOrdenado);
            this.Controls.Add(this.lblDatosGenerados);
            this.Controls.Add(this.lblCantidadDatos);
            this.Controls.Add(this.btnOrdenar);
            this.Controls.Add(this.gpbCriterio);
            this.Controls.Add(this.gpbOrden);
            this.Controls.Add(this.btnGenerar);
            this.Controls.Add(this.dtgAlumno);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCantidad);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Form1";
            this.Text = "Radix Sort";
            ((System.ComponentModel.ISupportInitialize)(this.dtgAlumno)).EndInit();
            this.gpbOrden.ResumeLayout(false);
            this.gpbOrden.PerformLayout();
            this.gpbCriterio.ResumeLayout(false);
            this.gpbCriterio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgAlumnoOrdenado)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtCantidad;
        private Label label1;
        private DataGridView dtgAlumno;
        private Button btnGenerar;
        private GroupBox gpbOrden;
        private GroupBox gpbCriterio;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private RadioButton radPromedio;
        private RadioButton radNombre;
        private RadioButton radClave;
        private RadioButton radDescendente;
        private RadioButton radAscendente;
        private Button btnOrdenar;
        private Label lblCantidadDatos;
        private Label lblDatosGenerados;
        private DataGridView dtgAlumnoOrdenado;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private Button btnSalir;
    }
}