﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;

namespace RadixSort
{
    class RadixSort
    {
        public delegate bool ModoDeOrdenar(Alumno primerAlumno, Alumno otroAlumno, Alumno.AtributoComparable Campo);

        public static bool OrdenarAscendente(Alumno primerAlumno, Alumno otroAlumno, Alumno.AtributoComparable Campo)
        {
            if (Campo(primerAlumno, otroAlumno) > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool OrdenarDescendente(Alumno primerAlumno, Alumno otroAlumno, Alumno.AtributoComparable Campo)
        {
            if (Campo(primerAlumno, otroAlumno) < 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public static void OrdenarRadixSortInt(Alumno[] miArregloDeAlumnos, Func<Alumno, int> obtenerCampo, ModoDeOrdenar Orden)
        {
            int maximo = 0;
            int tamañoArreglo= miArregloDeAlumnos.Length;

            // Contador para los movimientos
            int movimientos = 0;

            // Medir tiempo 
            Stopwatch Timer = Stopwatch.StartNew();

            // Encontrar la longitud máxima para determinar el rango de dígitos
            foreach (var alumno in miArregloDeAlumnos)
            {
                int valor = obtenerCampo(alumno);
                if (valor > maximo)
                {
                    maximo = valor;
                }
            }

            // Ordenar por RadixSort
            for (int exp = 1; maximo / exp > 0; exp *= 10)
            {
                int[] buckets = new int[10];
                Alumno[] salida = new Alumno[tamañoArreglo];

                // Asignar cada elemento a su bucket correspondiente
                for (int i = 0; i < tamañoArreglo; i++)
                {
                    int valor = (obtenerCampo(miArregloDeAlumnos[i]) / exp) % 10;
                    buckets[valor]++;
                }

                if (Orden == OrdenarDescendente)
                {
                    int total = 0;
                    for (int i = 9; i >= 0; i--)
                    {
                        int count = buckets[i];
                        buckets[i] = total;
                        total += count;
                    }
                }
                else // OrdenarAscendente
                {
                    int total = 0;
                    for (int i = 0; i < 10; i++)
                    {
                        int count = buckets[i];
                        buckets[i] = total;
                        total += count;
                    }
                }

                // Construir el array de salida ordenado
                for (int i = 0; i < tamañoArreglo; i++)
                {
                    int valor = (obtenerCampo(miArregloDeAlumnos[i]) / exp) % 10;
                    salida[buckets[valor]] = miArregloDeAlumnos[i];
                    buckets[valor]++;
                    movimientos++;
                }

                // Copiar el array de salida ordenado al array original
                for (int i = 0; i < tamañoArreglo; i++)
                {
                    miArregloDeAlumnos[i] = salida[i];
                }
            }
            Timer.Stop();
            double timerMilisegundos = Timer.Elapsed.TotalMilliseconds;
            MessageBox.Show($"Movimientos: {movimientos} \nTiempo en ordenar: {timerMilisegundos.ToString("F2")} milisegundos");
        }

        public static void OrdenarRadixSortString(Alumno[] miArregloDeAlumnos, Func<Alumno, string> obtenerCampo, ModoDeOrdenar Orden)
        {
            int n = miArregloDeAlumnos.Length;
            int movimientos = 0;
            int maxLength = 0;

            foreach (var alumno in miArregloDeAlumnos)
            {
                int length = obtenerCampo(alumno).Length;
                if (length > maxLength)
                {
                    maxLength = length;
                }
            }

            Stopwatch Timer = Stopwatch.StartNew();

            for (int i = maxLength - 1; i >= 0; i--)
            {
                int[] buckets = new int[256]; // Se usan 256 buckets para el rango de caracteres ASCII extendido
                Alumno[] salida = new Alumno[n];

                for (int j = 0; j < n; j++)
                {
                    string valor = obtenerCampo(miArregloDeAlumnos[j]);
                    int charIndex = i < valor.Length ? (int)valor[i] : 0; // Obtener el índice del carácter ASCII o 0 si la longitud es menor
                    buckets[charIndex]++;
                }

                if (Orden == OrdenarDescendente)
                {
                    for (int j = 254; j >= 0; j--)
                    {
                        buckets[j] += buckets[j + 1];
                    }
                }
                else // OrdenarAscendente
                {
                    for (int j = 1; j < 256; j++)
                    {
                        buckets[j] += buckets[j - 1];
                    }
                }

                for (int j = n - 1; j >= 0; j--)
                {
                    string valor = obtenerCampo(miArregloDeAlumnos[j]);
                    int charIndex = i < valor.Length ? (int)valor[i] : 0; // Obtener el índice del carácter ASCII o 0 si la longitud es menor
                    salida[buckets[charIndex] - 1] = miArregloDeAlumnos[j];
                    buckets[charIndex]--;
                    movimientos++;
                }

                for (int j = 0; j < n; j++)
                {
                    miArregloDeAlumnos[j] = salida[j];
                }
            }

            Timer.Stop();
            double timerMilisegundos = Timer.Elapsed.TotalMilliseconds;
            MessageBox.Show($"Movimientos: {movimientos} \nTiempo en ordenar: {timerMilisegundos.ToString("F2")} milisegundos");
        }

        public static void OrdenarRadixSortDouble(Alumno[] miClase, Func<Alumno, double> obtenerCampo, ModoDeOrdenar Orden)
        {
            double maximo = 0;
            int n = miClase.Length;

            // Contador de Movimientos
            int movimientos = 0;

            // Medir tiempo 
            Stopwatch Timer = Stopwatch.StartNew();

            foreach (var alumno in miClase)
            {
                double valor = obtenerCampo(alumno);
                if (valor > maximo)
                {
                    maximo = valor;
                }
            }

            // Ordenar por RadixSort
            for (double exp = 1; maximo / exp > 0; exp *= 10)
            {
                int[] buckets = new int[10];
                Alumno[] salida = new Alumno[n];

                // Asignar cada elemento a su bucket correspondiente
                for (int i = 0; i < n; i++)
                {
                    int valor = (int)((obtenerCampo(miClase[i]) / exp) % 10);
                    buckets[valor]++;
                }

                if (Orden == OrdenarDescendente)
                {
                    for (int i = 8; i >= 0; i--)
                    {
                        buckets[i] += buckets[i + 1];
                    }
                }
                else
                {
                    for (int i = 1; i < 10; i++)
                    {
                        buckets[i] += buckets[i - 1];
                    }
                }

                // Construir el array de salida ordenado
                for (int i = n - 1; i >= 0; i--)
                {
                    int valor = (int)((obtenerCampo(miClase[i]) / exp) % 10);
                    salida[buckets[valor] - 1] = miClase[i];
                    buckets[valor]--;
                    movimientos++;
                }

                // Copiar el array de salida ordenado al array original
                for (int i = 0; i < n; i++)
                {
                    miClase[i] = salida[i];
                }
            }
            Timer.Stop();
            double timerMilisegundos = Timer.Elapsed.TotalMilliseconds;
            MessageBox.Show($"Movimientos: {movimientos} \nTiempo en ordenar: {timerMilisegundos.ToString("F2")} milisegundos");
        }
    }

}
