using System.Diagnostics;

namespace RadixSort
{
    public partial class Form1 : Form
    {
        Alumno[] arr;
        public Form1()
        {
            InitializeComponent();
        }
        public void ImprimirArreglo()
        {
            dtgAlumno.Rows.Clear();

            foreach (Alumno unAlumno in arr)
            {
                dtgAlumno.Rows.Add(unAlumno.Clave, unAlumno.Nombre, unAlumno.Promedio);
            }
            dtgAlumno.Refresh();
        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            try
            {

                Random random = new Random();
                int intCantidadDatos = 0;
                string[] strNombres = new string[50]
                {
                "Juan", "Mar�a", "Carlos", "Ana", "Luis", "Laura", "Pedro", "Sof�a",
            "Miguel", "Luc�a", "Diego", "Valentina", "Javier", "Camila", "Andr�s",
            "Isabella", "Ricardo", "Paula", "Fernando", "Daniela", "Manuel", "Gabriela",
            "Sebasti�n", "Mariana", "Alejandro", "Catalina", "Felipe", "Antonella",
            "Gustavo", "Ver�nica", "Hugo", "Melanie", "Raul", "Gabriela", "Emilio",
            "Renata", "Roberto", "Florencia", "Julio", "Abril", "Eduardo", "Natalia",
            "Rodrigo", "Marcela", "Andr�s", "Carolina", "Fernando", "Patricia",
            "Santiago", "Claudia"
                };


                if (txtCantidad.Text == "")
                {
                    throw new Exception("Ingrese la cantidad de datos que desea tener");
                }

                //Condicion para confirmar la accion
                DialogResult Respuesta;
                Respuesta = MessageBox.Show("�Est�s seguro que quieres generar " + txtCantidad.Text + " datos?", "Confirme la operaci�n",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (Respuesta == DialogResult.Yes)
                {
                

                int intAleatorios = int.Parse(txtCantidad.Text);
                arr = new Alumno[intAleatorios];
                int i = 0;

                while (i < intAleatorios)
                {
                    Random aleatorioPromedio = new Random();
                    Alumno miAlumno = new Alumno();
                    miAlumno.Clave = random.Next(1000, 2000);
                    miAlumno.Nombre = strNombres[random.Next(strNombres.Length)];
                    miAlumno.Promedio = double.Parse(aleatorioPromedio.Next(7, 10).ToString() + Math.Round(aleatorioPromedio.NextDouble() * 10, 2));

                    arr[i] = miAlumno;
                    intCantidadDatos = arr.Length;
                    i = i + 1;
                }

                ImprimirArreglo();
                MessageBox.Show("Se han generado los datos correctamente.", "Generacion de Datos Exitosa");
                lblCantidadDatos.Text = intCantidadDatos.ToString();

                }

                else
                {
                    MessageBox.Show("Salida cancelada");
                }

            }

            catch (OverflowException ex)
            {
                MessageBox.Show(ex.Message, "!!ERROR!!");
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show(ex.Message, "!!ERROR!!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "!!ERROR!!");
            }

        }

        private void btnOrdenar_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtgAlumno.RowCount == 0 )
                {
                    throw new Exception("La lista se encuentra vacia");
                }

                //Condicion para confirmar la accion
                DialogResult Respuesta;
                Respuesta = MessageBox.Show("�Est�s seguro que ordenar los datos?", "Confirme la operaci�n",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (Respuesta == DialogResult.Yes)
                {

                //Orden Ascendente
                if (radAscendente.Checked && radClave.Checked)
                {
                    RadixSort.OrdenarRadixSortInt(arr, alumno => alumno.Clave, RadixSort.OrdenarAscendente);
                }
                if (radAscendente.Checked && radNombre.Checked)
                {
                    RadixSort.OrdenarRadixSortString(arr, alumno => alumno.Nombre, RadixSort.OrdenarAscendente);
                }
                if (radAscendente.Checked && radPromedio.Checked)
                {
                    RadixSort.OrdenarRadixSortDouble(arr, alumno => alumno.Promedio, RadixSort.OrdenarAscendente);
                }
                //Orden Descendente
                if (radDescendente.Checked && radClave.Checked)
                {
                    RadixSort.OrdenarRadixSortInt(arr, alumno => alumno.Clave, RadixSort.OrdenarDescendente);
                }
                if (radDescendente.Checked && radNombre.Checked)
                {
                    RadixSort.OrdenarRadixSortString(arr, alumno => alumno.Nombre, RadixSort.OrdenarDescendente);
                }
                if (radDescendente.Checked && radPromedio.Checked)
                {
                    RadixSort.OrdenarRadixSortDouble(arr, alumno => alumno.Promedio, RadixSort.OrdenarDescendente);
                }

                    ImprimirArregloOrdenado();

                }

                else
                {
                    MessageBox.Show("Ordenamiento cancelado");
                }
            }

            catch (OverflowException ex)
            {
                MessageBox.Show(ex.Message, "!!ERROR!!");
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show(ex.Message, "!!ERROR!!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "!!ERROR!!");
            }
        }

        public void ImprimirArregloOrdenado()
        {
            dtgAlumnoOrdenado.Rows.Clear();

            foreach (Alumno unAlumno in arr)
            {
                dtgAlumnoOrdenado.Rows.Add(unAlumno.Clave, unAlumno.Nombre, unAlumno.Promedio);
            }
            dtgAlumnoOrdenado.Refresh();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            //Condicion para confirmar la accion
            DialogResult Respuesta;
            Respuesta = MessageBox.Show("�Est�s seguro que quieres salir del programa?", "Confirme la operaci�n",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Respuesta == DialogResult.Yes)
            {
                Application.Exit();
            }

            else
            {
                MessageBox.Show("Salida cancelada");
            }
        }
    }
}