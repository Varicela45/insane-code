using System.Windows.Forms;

namespace ExposicionObjetos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class ClaseNodo<Tipo>
        {
            Tipo _objetoConDatos;
            ClaseNodo<Tipo> _siguiente;
            public Tipo ObjetoConDatos
            {
                get { return _objetoConDatos; }
                set { _objetoConDatos = value; }
            }
            public ClaseNodo<Tipo> Siguiente
            {
                get { return _siguiente; }
                set { _siguiente = value; }
            }
            ~ClaseNodo()
            {
                ObjetoConDatos = default;
            }
        }
        class ClaseListaSimpleOrdenada<Tipo> where Tipo : IComparable<Tipo>, IEquatable<Tipo>
        {
            public ClaseListaSimpleOrdenada()
            { }
            interface IComparable<Tipo>
            {
                int CompareTo(Tipo obj);
            }
            interface IEquatable<Tipo>
            {
                bool Equals(Tipo obj);
            }
            ClaseNodo<Tipo> _nodoInicial;
            ClaseNodo<Tipo> NodoInicial
            {
                get { return _nodoInicial; }
                set { _nodoInicial = value; }
            }
            public  ClaseNodo<Tipo> ObtenerNodoInicial()
            {
                return NodoInicial;
            }
            public void EstablecerNodoInicial(ClaseNodo<Tipo> nuevoNodoInicial)
            {
                _nodoInicial = nuevoNodoInicial;
            }
            public bool EstaVacia()
            {
                if (NodoInicial == null)
                {
                    return true;
                }
                return false;
            }
            public void InsertarNodo(Tipo objeto)
            {
                if (EstaVacia())
                {
                    ClaseNodo<Tipo> nodoNuevo = new ClaseNodo<Tipo>();
                    nodoNuevo.ObjetoConDatos = objeto;
                    nodoNuevo.Siguiente = null;
                    NodoInicial = nodoNuevo;

                    return;
                }
                else
                {
                    ClaseNodo<Tipo> nodoActual = new ClaseNodo<Tipo>();
                    nodoActual = NodoInicial;
                    ClaseNodo<Tipo> nodoPrevio = new ClaseNodo<Tipo>();

                    do
                    {
                        if (objeto.Equals(nodoActual.ObjetoConDatos))
                        {
                            throw new Exception("Este objeto ya existe en la lista");
                        }

                        nodoPrevio = nodoActual;
                        nodoActual = nodoActual.Siguiente;

                    } while (nodoActual != null);
                    {

                        ClaseNodo<Tipo> nodoNuevo = new ClaseNodo<Tipo>();
                        nodoNuevo.ObjetoConDatos = objeto;
                        nodoPrevio.Siguiente = nodoNuevo;
                        nodoNuevo.Siguiente = null;

                        return;
                    }
                }
            }

            public IEnumerator<Tipo> GetEnumerator()
            {
                if (EstaVacia())
                {
                    yield break;
                }
                else
                {
                    ClaseNodo<Tipo> nodoActu = new ClaseNodo<Tipo>();
                    nodoActu = NodoInicial;
                    do
                    {
                        yield return nodoActu.ObjetoConDatos;
                        nodoActu = nodoActu.Siguiente;
                    } while (nodoActu != null);

                    yield break;
                }
            }

        }
        ClaseListaSimpleOrdenada<Playa> miPlaya = new ClaseListaSimpleOrdenada<Playa>();


        private void btnGenerar_Click(object sender, EventArgs e)
        {
            try
            {
                for (int x = 1; x < 11; x++)
                {
                    Playa playa = new Playa();
                    Random aleatorio = new Random();
                    playa.ClavePlaya = aleatorio.Next(1, 1000);
                    textBox1.Text = playa.ClavePlaya.ToString();

                    playa.CoordenadaY = Math.Round(aleatorio.NextDouble() * 100, 1);
                    textBox2.Text = playa.CoordenadaY.ToString();

                    playa.CoordenadaX = Math.Round(aleatorio.NextDouble() * 100, 1);
                    textBox3.Text = playa.CoordenadaX.ToString();

                    playa.NombrePlaya = Guid.NewGuid().ToString().Substring(0, 10);
                    textBox4.Text = playa.NombrePlaya.ToString();
                    miPlaya.InsertarNodo(playa);

                    dataGridView1.Rows.Clear();
                    foreach (Playa mplaya in miPlaya)
                    {
                        dataGridView1.Rows.Add(mplaya.ClavePlaya, mplaya.NombrePlaya,
                        mplaya.CoordenadaX, mplaya.CoordenadaY);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void Limpiar()
        {

            txtMovimientos.Text = "";
            txtPreguntas.Text = "";
            txtTiempo.Text = "";
        }

        private void btnOrdenar1_Click(object sender, EventArgs e)
        {
            Limpiar();
            bool ejecutar = false;
            int preguntas = 0;
            int movimientos = 0;
            var Cronometro = new System.Diagnostics.Stopwatch();
            Cronometro.Start();
            dataGridView2.Rows.Clear();
            try
            {

                if (rdbAscendente.Checked)
                {
                    Limpiar();
                    int n = 0;

                    // Contar el n�mero de elementos en la lista
                    foreach (Playa mplaya in miPlaya)
                    {
                        n++;
                    }

                    int mitad = n / 2;
                    while (mitad > 0)
                    {
                        ejecutar = true;
                        while (ejecutar)
                        {
                            ejecutar = false;
                            int i = 1;
                            ClaseNodo<Playa> nodoActual = miPlaya.ObtenerNodoInicial();
                            ClaseNodo<Playa> nodoPrevio = null;

                            while (nodoActual != null && nodoActual.Siguiente != null && nodoActual.ObjetoConDatos != null && nodoActual.ObjetoConDatos.ClavePlaya != null &&
                          nodoActual.Siguiente.ObjetoConDatos != null && nodoActual.Siguiente.ObjetoConDatos.ClavePlaya != null && i <= n - mitad)
                            {
                                if (nodoActual.ObjetoConDatos.ClavePlaya.CompareTo(nodoActual.Siguiente.ObjetoConDatos.ClavePlaya) > 0)
                                {
                                    // Intercambiar los elementos en la lista
                                    var auxiliar = nodoActual.Siguiente;
                                    nodoActual.Siguiente = nodoActual.Siguiente.Siguiente;

                                    if (nodoPrevio != null)
                                    {
                                        nodoPrevio.Siguiente = auxiliar;
                                    }
                                    else
                                    {
                                        miPlaya.EstablecerNodoInicial(auxiliar);
                                    }

                                    auxiliar.Siguiente = nodoActual;
                                    ejecutar = true;
                                    movimientos++;
                                }
                                preguntas++;
                                nodoPrevio = nodoActual;
                                nodoActual = nodoActual.Siguiente;
                                i++;
                            }
                        }
                        mitad = mitad / 2;
                    }

                    // Limpiando y llenando dataGridView2 con los resultados ordenados
                    dataGridView2.Rows.Clear();
                    foreach (Playa mplaya in miPlaya)
                    {
                        dataGridView2.Rows.Add(mplaya.ClavePlaya, mplaya.NombrePlaya, mplaya.CoordenadaX, mplaya.CoordenadaY);
                    }

                    Cronometro.Stop();
                    TimeSpan _TiempoTranscurrido = Cronometro.Elapsed;
                    string _TiempoTotal = String.Format("{0:00}:{1:00}:{2:00}.{3:00}", _TiempoTranscurrido.Hours, _TiempoTranscurrido.Minutes, _TiempoTranscurrido.Seconds, _TiempoTranscurrido.Milliseconds / 10);
                    txtPreguntas.Text = preguntas.ToString();
                    txtMovimientos.Text = movimientos.ToString();
                    txtTiempo.Text = _TiempoTotal.ToString();
                }
                if (rdbDescendente.Checked)
                {
                    Limpiar();
                    int n = 0;

                    // Contar el n�mero de elementos en la lista
                    foreach (Playa mplaya in miPlaya)
                    {
                        n++;
                    }

                    int mitad = n / 2;
                    while (mitad > 0)
                    {
                        ejecutar = true;
                        while (ejecutar)
                        {
                            ejecutar = false;
                            int i = 1;
                            ClaseNodo<Playa> nodoActual = miPlaya.ObtenerNodoInicial();
                            ClaseNodo<Playa> nodoPrevio = null;

                            while (nodoActual != null  && nodoActual.Siguiente != null && nodoActual.ObjetoConDatos != null && nodoActual.ObjetoConDatos.ClavePlaya != null &&
                              nodoActual.Siguiente.ObjetoConDatos != null && nodoActual.Siguiente.ObjetoConDatos.ClavePlaya != null && i <= n - mitad)
                            {
                                if (nodoActual.ObjetoConDatos.ClavePlaya < nodoActual.Siguiente.ObjetoConDatos.ClavePlaya)
                                {
                                    // Intercambiar los elementos en la lista
                                    var auxiliar = nodoActual.Siguiente;
                                    nodoActual.Siguiente = nodoActual.Siguiente.Siguiente;

                                    if (nodoPrevio != null)
                                    {
                                        nodoPrevio.Siguiente = auxiliar;
                                    }
                                    else
                                    {
                                        miPlaya.EstablecerNodoInicial(auxiliar);
                                    }

                                    auxiliar.Siguiente = nodoActual;
                                    ejecutar = true;
                                    movimientos++;
                                }
                                preguntas++;
                                nodoPrevio = nodoActual;
                                nodoActual = nodoActual.Siguiente;
                                i++;
                            }
                        }
                        mitad = mitad / 2;
                    }

                    // Limpiando y llenando dataGridView2 con los resultados ordenados
                    dataGridView2.Rows.Clear();
                    foreach (Playa mplaya in miPlaya)
                    {
                        dataGridView2.Rows.Add(mplaya.ClavePlaya, mplaya.NombrePlaya, mplaya.CoordenadaX, mplaya.CoordenadaY);
                    }

                    Cronometro.Stop();
                    TimeSpan _TiempoTranscurrido = Cronometro.Elapsed;
                    string _TiempoTotal = String.Format("{0:00}:{1:00}:{2:00}.{3:00}", _TiempoTranscurrido.Hours, _TiempoTranscurrido.Minutes, _TiempoTranscurrido.Seconds, _TiempoTranscurrido.Milliseconds / 10);
                    txtPreguntas.Text = preguntas.ToString();
                    txtMovimientos.Text = movimientos.ToString();
                    txtTiempo.Text = _TiempoTotal.ToString();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}