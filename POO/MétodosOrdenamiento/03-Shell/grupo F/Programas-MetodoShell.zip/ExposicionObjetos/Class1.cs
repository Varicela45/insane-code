﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExposicionObjetos
{
    internal class Playa : IComparable<Playa>, IEquatable<Playa>
    {
        private int _intClavePlaya;
        private double _dblCoordenadaY;
        private double _dblCoordenadaX;
        private string _strNombrePlaya;
        public int ClavePlaya
        {
            get { return _intClavePlaya; }
            set { _intClavePlaya = value; }
        }
        public double CoordenadaY
        {
            get { return _dblCoordenadaY; }
            set { _dblCoordenadaY = value; }
        }
        public double CoordenadaX
        {
            get { return _dblCoordenadaX; }
            set { _dblCoordenadaX = value; }
        }
        public string NombrePlaya
        {
            get { return _strNombrePlaya; }
            set { _strNombrePlaya = value; }
        }

        public Playa()
        {
            _intClavePlaya = 0;
            _dblCoordenadaY = 0.0;
            _dblCoordenadaX = 0.0;
            _strNombrePlaya = "";
        }
        public int CompareTo(Playa p)
        {
            return (this.ClavePlaya.CompareTo(p.ClavePlaya));
        }
        public bool Equals(Playa p)
        {
            if (this.ClavePlaya.ToString() == p.ClavePlaya.ToString())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
