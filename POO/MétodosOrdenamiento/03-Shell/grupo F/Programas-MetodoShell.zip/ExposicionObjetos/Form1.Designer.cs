﻿namespace ExposicionObjetos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            txtTiempo = new TextBox();
            groupBox3 = new GroupBox();
            rdbDescendente = new RadioButton();
            rdbAscendente = new RadioButton();
            label5 = new Label();
            txtMovimientos = new TextBox();
            txtPreguntas = new TextBox();
            label2 = new Label();
            label1 = new Label();
            grpboxOrdenados = new GroupBox();
            dataGridView2 = new DataGridView();
            Clave = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            CoordenadaY = new DataGridViewTextBoxColumn();
            grpboxValores = new GroupBox();
            btnSalir = new Button();
            dataGridView1 = new DataGridView();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            btnOrdenar1 = new Button();
            btnGenerar = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            grpboxOrdenados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            grpboxValores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(txtTiempo);
            groupBox2.Controls.Add(groupBox3);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(txtMovimientos);
            groupBox2.Controls.Add(txtPreguntas);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(72, 38);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(533, 351);
            groupBox2.TabIndex = 11;
            groupBox2.TabStop = false;
            groupBox2.Text = "Informacion";
            // 
            // txtTiempo
            // 
            txtTiempo.Location = new Point(322, 103);
            txtTiempo.Name = "txtTiempo";
            txtTiempo.Size = new Size(198, 31);
            txtTiempo.TabIndex = 9;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(rdbDescendente);
            groupBox3.Controls.Add(rdbAscendente);
            groupBox3.Location = new Point(17, 156);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(220, 150);
            groupBox3.TabIndex = 7;
            groupBox3.TabStop = false;
            groupBox3.Text = "Tipo De Ordenamiento";
            // 
            // rdbDescendente
            // 
            rdbDescendente.AutoSize = true;
            rdbDescendente.Location = new Point(12, 84);
            rdbDescendente.Name = "rdbDescendente";
            rdbDescendente.Size = new Size(139, 29);
            rdbDescendente.TabIndex = 1;
            rdbDescendente.TabStop = true;
            rdbDescendente.Text = "Descendente";
            rdbDescendente.UseVisualStyleBackColor = true;
            // 
            // rdbAscendente
            // 
            rdbAscendente.AutoSize = true;
            rdbAscendente.Location = new Point(9, 44);
            rdbAscendente.Name = "rdbAscendente";
            rdbAscendente.Size = new Size(129, 29);
            rdbAscendente.TabIndex = 0;
            rdbAscendente.TabStop = true;
            rdbAscendente.Text = "Ascendente";
            rdbAscendente.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(17, 103);
            label5.Name = "label5";
            label5.Size = new Size(182, 25);
            label5.TabIndex = 8;
            label5.Text = "Tiempo Transcurrido: ";
            // 
            // txtMovimientos
            // 
            txtMovimientos.Location = new Point(322, 65);
            txtMovimientos.Name = "txtMovimientos";
            txtMovimientos.Size = new Size(198, 31);
            txtMovimientos.TabIndex = 5;
            // 
            // txtPreguntas
            // 
            txtPreguntas.Location = new Point(322, 21);
            txtPreguntas.Name = "txtPreguntas";
            txtPreguntas.Size = new Size(198, 31);
            txtPreguntas.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(17, 65);
            label2.Name = "label2";
            label2.Size = new Size(192, 25);
            label2.TabIndex = 1;
            label2.Text = "Total de movimientos: ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 27);
            label1.Name = "label1";
            label1.Size = new Size(168, 25);
            label1.TabIndex = 0;
            label1.Text = "Total de preguntas: ";
            // 
            // grpboxOrdenados
            // 
            grpboxOrdenados.Controls.Add(dataGridView2);
            grpboxOrdenados.Location = new Point(624, 31);
            grpboxOrdenados.Name = "grpboxOrdenados";
            grpboxOrdenados.Size = new Size(682, 372);
            grpboxOrdenados.TabIndex = 10;
            grpboxOrdenados.TabStop = false;
            grpboxOrdenados.Text = "Ordenados";
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Columns.AddRange(new DataGridViewColumn[] { Clave, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn1, CoordenadaY });
            dataGridView2.Location = new Point(11, 34);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.ReadOnly = true;
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.RowTemplate.Height = 33;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView2.Size = new Size(646, 324);
            dataGridView2.TabIndex = 29;
            dataGridView2.TabStop = false;
            // 
            // Clave
            // 
            Clave.Frozen = true;
            Clave.HeaderText = "Clave";
            Clave.MinimumWidth = 8;
            Clave.Name = "Clave";
            Clave.ReadOnly = true;
            Clave.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.Frozen = true;
            dataGridViewTextBoxColumn2.HeaderText = "Nombre De La Playa";
            dataGridViewTextBoxColumn2.MinimumWidth = 8;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.ReadOnly = true;
            dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.Frozen = true;
            dataGridViewTextBoxColumn1.HeaderText = "Coordenada X";
            dataGridViewTextBoxColumn1.MinimumWidth = 8;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.ReadOnly = true;
            dataGridViewTextBoxColumn1.Width = 150;
            // 
            // CoordenadaY
            // 
            CoordenadaY.HeaderText = "Coordenada Y";
            CoordenadaY.MinimumWidth = 8;
            CoordenadaY.Name = "CoordenadaY";
            CoordenadaY.ReadOnly = true;
            CoordenadaY.Width = 150;
            // 
            // grpboxValores
            // 
            grpboxValores.Controls.Add(btnSalir);
            grpboxValores.Controls.Add(dataGridView1);
            grpboxValores.Controls.Add(btnOrdenar1);
            grpboxValores.Controls.Add(btnGenerar);
            grpboxValores.Location = new Point(72, 395);
            grpboxValores.Name = "grpboxValores";
            grpboxValores.Size = new Size(907, 373);
            grpboxValores.TabIndex = 9;
            grpboxValores.TabStop = false;
            grpboxValores.Text = "Valores";
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(703, 167);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(112, 34);
            btnSalir.TabIndex = 11;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6 });
            dataGridView1.Location = new Point(15, 30);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(668, 321);
            dataGridView1.TabIndex = 30;
            dataGridView1.TabStop = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.Frozen = true;
            dataGridViewTextBoxColumn3.HeaderText = "Clave";
            dataGridViewTextBoxColumn3.MinimumWidth = 8;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            dataGridViewTextBoxColumn3.ReadOnly = true;
            dataGridViewTextBoxColumn3.Width = 150;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.Frozen = true;
            dataGridViewTextBoxColumn4.HeaderText = "Nombre De La Playa";
            dataGridViewTextBoxColumn4.MinimumWidth = 8;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            dataGridViewTextBoxColumn4.ReadOnly = true;
            dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.Frozen = true;
            dataGridViewTextBoxColumn5.HeaderText = "Coordenada X";
            dataGridViewTextBoxColumn5.MinimumWidth = 8;
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            dataGridViewTextBoxColumn5.ReadOnly = true;
            dataGridViewTextBoxColumn5.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewTextBoxColumn6.HeaderText = "Coordenada Y";
            dataGridViewTextBoxColumn6.MinimumWidth = 8;
            dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            dataGridViewTextBoxColumn6.ReadOnly = true;
            dataGridViewTextBoxColumn6.Width = 150;
            // 
            // btnOrdenar1
            // 
            btnOrdenar1.Location = new Point(703, 99);
            btnOrdenar1.Name = "btnOrdenar1";
            btnOrdenar1.Size = new Size(112, 34);
            btnOrdenar1.TabIndex = 10;
            btnOrdenar1.Text = "Ordenar";
            btnOrdenar1.UseVisualStyleBackColor = true;
            btnOrdenar1.Click += btnOrdenar1_Click;
            // 
            // btnGenerar
            // 
            btnGenerar.Location = new Point(703, 42);
            btnGenerar.Name = "btnGenerar";
            btnGenerar.Size = new Size(112, 34);
            btnGenerar.TabIndex = 3;
            btnGenerar.Text = "Generar";
            btnGenerar.UseVisualStyleBackColor = true;
            btnGenerar.Click += btnGenerar_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(1379, 55);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(150, 31);
            textBox1.TabIndex = 12;
            textBox1.Visible = false;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(1379, 116);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(150, 31);
            textBox2.TabIndex = 13;
            textBox2.Visible = false;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(1379, 194);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(150, 31);
            textBox3.TabIndex = 14;
            textBox3.Visible = false;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(1379, 264);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(150, 31);
            textBox4.TabIndex = 15;
            textBox4.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1674, 875);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(groupBox2);
            Controls.Add(grpboxOrdenados);
            Controls.Add(grpboxValores);
            Name = "Form1";
            Text = "Form1";
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            grpboxOrdenados.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            grpboxValores.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox2;
        private TextBox txtTiempo;
        private GroupBox groupBox3;
        private RadioButton rdbDescendente;
        private RadioButton rdbAscendente;
        private Label label5;
        private TextBox txtMovimientos;
        private TextBox txtPreguntas;
        private Label label2;
        private Label label1;
        private GroupBox grpboxOrdenados;
        private GroupBox grpboxValores;
        private Button btnSalir;
        private Button btnOrdenar1;
        private Button btnGenerar;
        private DataGridView dataGridView2;
        private DataGridViewTextBoxColumn Clave;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn CoordenadaY;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
    }
}