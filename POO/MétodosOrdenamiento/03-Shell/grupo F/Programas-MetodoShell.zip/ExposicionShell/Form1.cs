using System.CodeDom;
using System.CodeDom.Compiler;
using System.Diagnostics;

namespace ExposicionShell
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnOrdenar1_Click(object sender, EventArgs e)
        {
            int[] _valores = new int[lbxValores.Items.Count];
            bool ejecutar = false;
            int preguntas = 0;
            int movimientos = 0;
            int n = _valores.Length;
            int auxiliar = 0;
            var Cronometro = new System.Diagnostics.Stopwatch();
            Cronometro.Start();
            lbxOrdenados.Items.Clear();
            if (rdbAscendente.Checked)
            { 
                for (int i = 0; i < lbxValores.Items.Count; i++)
                {
                    _valores[i] = Convert.ToInt32(lbxValores.Items[i]);
                }

                int mitad = _valores.Length / 2;
                while (mitad > 0)
                {
                    ejecutar = true;
                    while (ejecutar)
                    {
                        ejecutar = false;
                        int i = 1;
                        while (i <= _valores.Length - mitad)
                        {
                            if (_valores[i - 1] > _valores[(i - 1) + mitad])
                            {
                                auxiliar = _valores[(i - 1) + mitad];
                                _valores[(i - 1) + mitad] = _valores[(i - 1)];
                                _valores[(i - 1)] = auxiliar;
                                ejecutar = true;
                                movimientos++;
                            }
                            preguntas++;
                            i++;
                        }
                    }
                    mitad = mitad / 2;
                }

                for (int i = 0; i < _valores.Length; i++)
                {
                    lbxOrdenados.Items.Add(_valores[i]);
                }

                Cronometro.Stop();
                TimeSpan _TiempoTranscurrido = Cronometro.Elapsed;
                string _TiempoTotal = String.Format("{0:00} : {1:00} : {2:00} . {3:00}", _TiempoTranscurrido.Hours, _TiempoTranscurrido.Minutes, _TiempoTranscurrido.Seconds, _TiempoTranscurrido.Milliseconds / 10);
                txtPreguntas.Text = preguntas.ToString();
                txtMovimientos.Text = movimientos.ToString();
                txtTiempo.Text = _TiempoTotal.ToString();
            }
            if (rdbDescendente.Checked)
            {
                for (int i = 0; i < lbxValores.Items.Count; i++)
                {
                    _valores[i] = Convert.ToInt32(lbxValores.Items[i]);
                }
                int mitad = _valores.Length / 2;
                while (mitad > 0)
                {
                    ejecutar = true;
                    while (ejecutar)
                    {
                        ejecutar = false;
                        int i = 1;
                        while (i <= _valores.Length - mitad)
                        {
                            if (_valores[i - 1] < _valores[(i - 1) + mitad])
                            {
                                auxiliar = _valores[(i - 1) + mitad];
                                _valores[(i - 1) + mitad] = _valores[(i - 1)];
                                _valores[(i - 1)] = auxiliar;
                                ejecutar = true;
                                movimientos++;
                            }
                            preguntas++;
                            i++;
                        }
                    }
                    mitad = mitad / 2;
                }
                for (int i = 0; i < n; i++)
                {
                    lbxOrdenados.Items.Add(_valores[i]);
                }
                Cronometro.Stop();
                TimeSpan _TiempoTranscurrido = Cronometro.Elapsed;
                string _TiempoTotal = String.Format("{0:00} : {1:00} : {2:00} . {3:00}", _TiempoTranscurrido.Hours, _TiempoTranscurrido.Minutes, _TiempoTranscurrido.Seconds, _TiempoTranscurrido.Milliseconds / 10);
                txtPreguntas.Text = preguntas.ToString();
                txtMovimientos.Text = movimientos.ToString();
                txtTiempo.Text = _TiempoTotal.ToString();
            }
    }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            try
            {
                Limpiar();
                lbxValores.Items.Clear();
                Random _numAleatorio = new Random();
                int _numero;
                for (int i = 0; i < Convert.ToInt32(cbxGenerar.Text); i++)
                {
                    do
                    {
                        _numero = _numAleatorio.Next(0, 5000);
                    } while (lbxValores.Items.Contains(_numero));
                    lbxValores.Items.Add(_numero);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Favor de seleccionar un numero para generar aleatorios");
            }

        }
        private void Limpiar()
        {

            txtMovimientos.Text = "";
            txtPreguntas.Text = "";
            txtTiempo.Text = "";
            lbxOrdenados.Items.Clear();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}