﻿namespace ExposicionShell
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rdbDescendente = new System.Windows.Forms.RadioButton();
            this.rdbAscendente = new System.Windows.Forms.RadioButton();
            this.grpboxOrdenados = new System.Windows.Forms.GroupBox();
            this.lbxOrdenados = new System.Windows.Forms.ListBox();
            this.grpboxValores = new System.Windows.Forms.GroupBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnOrdenar1 = new System.Windows.Forms.Button();
            this.cbxGenerar = new System.Windows.Forms.ComboBox();
            this.btnGenerar = new System.Windows.Forms.Button();
            this.lbxValores = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtTiempo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMovimientos = new System.Windows.Forms.TextBox();
            this.txtPreguntas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.grpboxOrdenados.SuspendLayout();
            this.grpboxValores.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rdbDescendente);
            this.groupBox3.Controls.Add(this.rdbAscendente);
            this.groupBox3.Location = new System.Drawing.Point(14, 125);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(176, 120);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tipo De Ordenamiento";
            // 
            // rdbDescendente
            // 
            this.rdbDescendente.AutoSize = true;
            this.rdbDescendente.Location = new System.Drawing.Point(10, 67);
            this.rdbDescendente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdbDescendente.Name = "rdbDescendente";
            this.rdbDescendente.Size = new System.Drawing.Size(116, 24);
            this.rdbDescendente.TabIndex = 1;
            this.rdbDescendente.TabStop = true;
            this.rdbDescendente.Text = "Descendente";
            this.rdbDescendente.UseVisualStyleBackColor = true;
            // 
            // rdbAscendente
            // 
            this.rdbAscendente.AutoSize = true;
            this.rdbAscendente.Location = new System.Drawing.Point(7, 35);
            this.rdbAscendente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rdbAscendente.Name = "rdbAscendente";
            this.rdbAscendente.Size = new System.Drawing.Size(107, 24);
            this.rdbAscendente.TabIndex = 0;
            this.rdbAscendente.TabStop = true;
            this.rdbAscendente.Text = "Ascendente";
            this.rdbAscendente.UseVisualStyleBackColor = true;
            // 
            // grpboxOrdenados
            // 
            this.grpboxOrdenados.Controls.Add(this.lbxOrdenados);
            this.grpboxOrdenados.Location = new System.Drawing.Point(698, 30);
            this.grpboxOrdenados.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpboxOrdenados.Name = "grpboxOrdenados";
            this.grpboxOrdenados.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpboxOrdenados.Size = new System.Drawing.Size(130, 256);
            this.grpboxOrdenados.TabIndex = 6;
            this.grpboxOrdenados.TabStop = false;
            this.grpboxOrdenados.Text = "Ordenados";
            // 
            // lbxOrdenados
            // 
            this.lbxOrdenados.FormattingEnabled = true;
            this.lbxOrdenados.ItemHeight = 20;
            this.lbxOrdenados.Location = new System.Drawing.Point(11, 38);
            this.lbxOrdenados.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbxOrdenados.Name = "lbxOrdenados";
            this.lbxOrdenados.Size = new System.Drawing.Size(96, 204);
            this.lbxOrdenados.TabIndex = 0;
            // 
            // grpboxValores
            // 
            this.grpboxValores.Controls.Add(this.btnSalir);
            this.grpboxValores.Controls.Add(this.btnOrdenar1);
            this.grpboxValores.Controls.Add(this.cbxGenerar);
            this.grpboxValores.Controls.Add(this.btnGenerar);
            this.grpboxValores.Controls.Add(this.lbxValores);
            this.grpboxValores.Location = new System.Drawing.Point(449, 30);
            this.grpboxValores.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpboxValores.Name = "grpboxValores";
            this.grpboxValores.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grpboxValores.Size = new System.Drawing.Size(231, 256);
            this.grpboxValores.TabIndex = 5;
            this.grpboxValores.TabStop = false;
            this.grpboxValores.Text = "Valores";
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(78, 152);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(90, 27);
            this.btnSalir.TabIndex = 11;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            // 
            // btnOrdenar1
            // 
            this.btnOrdenar1.Location = new System.Drawing.Point(78, 103);
            this.btnOrdenar1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnOrdenar1.Name = "btnOrdenar1";
            this.btnOrdenar1.Size = new System.Drawing.Size(90, 27);
            this.btnOrdenar1.TabIndex = 10;
            this.btnOrdenar1.Text = "Ordenar";
            this.btnOrdenar1.UseVisualStyleBackColor = true;
            // 
            // cbxGenerar
            // 
            this.cbxGenerar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxGenerar.FormattingEnabled = true;
            this.cbxGenerar.Items.AddRange(new object[] {
            "10 ",
            "50",
            "1000",
            "5000"});
            this.cbxGenerar.Location = new System.Drawing.Point(78, 29);
            this.cbxGenerar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbxGenerar.Name = "cbxGenerar";
            this.cbxGenerar.Size = new System.Drawing.Size(146, 28);
            this.cbxGenerar.TabIndex = 5;
            // 
            // btnGenerar
            // 
            this.btnGenerar.Location = new System.Drawing.Point(78, 60);
            this.btnGenerar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGenerar.Name = "btnGenerar";
            this.btnGenerar.Size = new System.Drawing.Size(90, 27);
            this.btnGenerar.TabIndex = 3;
            this.btnGenerar.Text = "Generar";
            this.btnGenerar.UseVisualStyleBackColor = true;
            // 
            // lbxValores
            // 
            this.lbxValores.FormattingEnabled = true;
            this.lbxValores.ItemHeight = 20;
            this.lbxValores.Location = new System.Drawing.Point(12, 24);
            this.lbxValores.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbxValores.Name = "lbxValores";
            this.lbxValores.Size = new System.Drawing.Size(62, 204);
            this.lbxValores.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtTiempo);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtMovimientos);
            this.groupBox2.Controls.Add(this.txtPreguntas);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(10, 26);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(426, 260);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Informacion";
            // 
            // txtTiempo
            // 
            this.txtTiempo.Location = new System.Drawing.Point(258, 82);
            this.txtTiempo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtTiempo.Name = "txtTiempo";
            this.txtTiempo.Size = new System.Drawing.Size(159, 27);
            this.txtTiempo.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 82);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Tiempo Transcurrido: ";
            // 
            // txtMovimientos
            // 
            this.txtMovimientos.Location = new System.Drawing.Point(258, 52);
            this.txtMovimientos.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtMovimientos.Name = "txtMovimientos";
            this.txtMovimientos.Size = new System.Drawing.Size(159, 27);
            this.txtMovimientos.TabIndex = 5;
            // 
            // txtPreguntas
            // 
            this.txtPreguntas.Location = new System.Drawing.Point(258, 17);
            this.txtPreguntas.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPreguntas.Name = "txtPreguntas";
            this.txtPreguntas.Size = new System.Drawing.Size(159, 27);
            this.txtPreguntas.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 52);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Total de movimientos: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Total de preguntas: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 314);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grpboxOrdenados);
            this.Controls.Add(this.grpboxValores);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.grpboxOrdenados.ResumeLayout(false);
            this.grpboxValores.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox3;
        private RadioButton rdbDescendente;
        private RadioButton rdbAscendente;
        private GroupBox grpboxOrdenados;
        private ListBox lbxOrdenados;
        private GroupBox grpboxValores;
        private Button btnOrdenar1;
        private ComboBox cbxGenerar;
        private Button btnGenerar;
        private ListBox lbxValores;
        private GroupBox groupBox2;
        private TextBox txtTiempo;
        private Label label5;
        private TextBox txtMovimientos;
        private TextBox txtPreguntas;
        private Label label2;
        private Label label1;
        private Button btnSalir;
    }
}