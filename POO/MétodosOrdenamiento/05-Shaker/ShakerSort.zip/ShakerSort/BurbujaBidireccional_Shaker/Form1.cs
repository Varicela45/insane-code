﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BurbujaBidireccional_Shaker
{
    public partial class Form1 : Form
    {

        Empleado[] DatosDeEmpleados;
        Random aleatorio;

        string[] strNombres = {"Valeria", "Leonardo", "Suli", "Joham", "Alberto", "Jose", "Carlos",
                                "Paola", "Manuel", "Ramon", "Jennifer", "Karla", "Hanna", "Fernando",
                                "Maria", "Karina", "Joana", "Jorge", "Aby", "Vanessa", "Isabel", "Joshua",
                                "Francisco", "Miguel", "Angel", "Ricardo", "Luis", "Daniel", "Juan", "Xavier",
                                "Pedro", "Samantha", "Alejadro", "Erick", "Abiram", "Leonel", "Roberto", "Adai",
                                "Winany", "Kassandra", "Arvizu", "Raul", "Jean", "Alexa", "Alfredo", "Cecilia", "Naida"};
        public Form1()
        {
            InitializeComponent();
            pbImagen.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        #region Generar Aleatorios
        private void btnRandom_Click(object sender, EventArgs e)
        {
            try
            {
                DatosDeEmpleados = new Empleado[Convert.ToInt64(cbxTamaño.Text)];

                aleatorio = new Random();

                for (int intCelda = 0; intCelda < Convert.ToInt64(cbxTamaño.Text); intCelda++)
                {


                    DatosDeEmpleados[intCelda] = new Empleado();

                    DatosDeEmpleados[intCelda].Nombre = strNombres[aleatorio.Next(0, 46)];
                    DatosDeEmpleados[intCelda].Codigo = aleatorio.Next(0,100000);
                    DatosDeEmpleados[intCelda].Sueldo = aleatorio.NextDouble() * 10000;

                    //MessageBox.Show(DatosDeEmpleados[intCelda].Nombre);
                }
                PintarTabla();
            }
            catch (Exception)
            {
                MessageBox.Show("Favor de ingresar un tamaño correctamente");
            }
        }

        #endregion


        #region Pintar Tabla
        public void PintarTabla()
        {
            dgvEmpleados.Rows.Clear();

            for (int intCelda = 0; intCelda < DatosDeEmpleados.Length; intCelda++)
            {
                dgvEmpleados.Rows.Add(DatosDeEmpleados[intCelda].Codigo,
                                      DatosDeEmpleados[intCelda].Nombre,
                                      DatosDeEmpleados[intCelda].Sueldo);
            }
        }

        #endregion


        #region Ordenar Ascendente
        public void OrdenarAscendente()
        {
            //Método de la Burbuja bidireccional
            int n = DatosDeEmpleados.Length;
            int _derecha, _izquierda = 0;
            _derecha = n - 1;

            //Variables para los datos
            int Comparaciones = 0, Preguntas = 0, Movimientos = 0, MovimientosIzquierda = 0, MovimientosDerecha = 0;

            Empleado EmpleadoAux;

            #region Ordenar por Codigo
            if (rdbCodigo.Checked)
            {
                do
                {
                    Comparaciones++;
                    for (int i = _izquierda; i < _derecha; i++)
                    {
                        if (DatosDeEmpleados[i].Codigo > DatosDeEmpleados[i + 1].Codigo)
                        {
                            //Condición cumplida, traspaso de números.
                            EmpleadoAux = DatosDeEmpleados[i];
                            DatosDeEmpleados[i] = DatosDeEmpleados[i + 1];
                            DatosDeEmpleados[i + 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosIzquierda++;
                        }
                        Preguntas++;
                    }
                    for (int j = _derecha; j > _izquierda; j--)
                    {
                        if (DatosDeEmpleados[j].Codigo < DatosDeEmpleados[j - 1].Codigo)
                        {
                            //Condición cumplida, traspaso de números.
                            EmpleadoAux = DatosDeEmpleados[j];
                            DatosDeEmpleados[j] = DatosDeEmpleados[j - 1];
                            DatosDeEmpleados[j - 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosDerecha++;
                        }
                        Preguntas++;
                    }
                    _izquierda++;
                    _derecha--;

                } while (_izquierda < _derecha);
            }
            #endregion


            #region Ordenar por Nombre
            if (rdbNombre.Checked)
            {
                do
                {
                    Comparaciones++;
                    for (int i = _izquierda; i < _derecha; i++)
                    {
                        if (DatosDeEmpleados[i].CompareTo(DatosDeEmpleados[i + 1]) > 0)
                        {
                            //Condición cumplida, traspaso de números.
                            EmpleadoAux = DatosDeEmpleados[i];
                            DatosDeEmpleados[i] = DatosDeEmpleados[i + 1];
                            DatosDeEmpleados[i + 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosIzquierda++;
                        }
                        Preguntas++;
                    }
                    for (int j = _derecha; j > _izquierda; j--)
                    {
                        if (DatosDeEmpleados[j].CompareTo(DatosDeEmpleados[j - 1]) < 0)
                        {
                            //Condición cumplida, traspaso de números.
                            EmpleadoAux = DatosDeEmpleados[j];
                            DatosDeEmpleados[j] = DatosDeEmpleados[j - 1];
                            DatosDeEmpleados[j - 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosDerecha++;
                        }
                        Preguntas++;
                    }
                    _izquierda++;
                    _derecha--;

                } while (_izquierda < _derecha);
            }
            #endregion


            #region Ordenar por Sueldo

            if (rdbSueldo.Checked)
            {
                do
                {
                    Comparaciones++;
                    for (int i = _izquierda; i < _derecha; i++)
                    {
                        if (DatosDeEmpleados[i].Sueldo > DatosDeEmpleados[i + 1].Sueldo)
                        {
                            //Condición cumplida, traspaso de números.
                            EmpleadoAux = DatosDeEmpleados[i];
                            DatosDeEmpleados[i] = DatosDeEmpleados[i + 1];
                            DatosDeEmpleados[i + 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosIzquierda++;
                        }
                        Preguntas++;
                    }
                    for (int j = _derecha; j > _izquierda; j--)
                    {
                        if (DatosDeEmpleados[j].Sueldo < DatosDeEmpleados[j - 1].Sueldo)
                        {
                            //Condición cumplida, traspaso de números.
                            EmpleadoAux = DatosDeEmpleados[j];
                            DatosDeEmpleados[j] = DatosDeEmpleados[j - 1];
                            DatosDeEmpleados[j - 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosDerecha++;
                        }
                        Preguntas++;
                    }
                    _izquierda++;
                    _derecha--;

                } while (_izquierda < _derecha);
            }

            #endregion


            #region Datos del procedimiento
            txtComp.Text = Comparaciones.ToString();
            txtPreg.Text = Preguntas.ToString();
            txtMovDer.Text = MovimientosDerecha.ToString();
            txtMovIzq.Text = MovimientosIzquierda.ToString();
            #endregion
        }

        #endregion


        #region Ordenar Descendente
        public void OrdenarDescendente()
        {
            int n = DatosDeEmpleados.Length;
            int _derecha, _izquierda = 0;
            _derecha = n - 1;

            //Valores para obtener todos los datos
            int Comparaciones = 0, Preguntas = 0, Movimientos = 0, MovimientosIzquierda = 0, MovimientosDerecha = 0;


            Empleado EmpleadoAux;

            #region Ordenar Por Codigo
            
            if (rdbCodigo.Checked)
            {
                do
                {
                    Comparaciones++;

                    for (int i = _izquierda; i < _derecha; i++)
                    {
                        if (DatosDeEmpleados[i].Codigo < DatosDeEmpleados[i + 1].Codigo)
                        {
                            //Condición cumplida, traspaso de empleados.
                            EmpleadoAux = DatosDeEmpleados[i];
                            DatosDeEmpleados[i] = DatosDeEmpleados[i + 1];
                            DatosDeEmpleados[i + 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosIzquierda++;
                        }
                        Preguntas++;
                    }
                    for (int j = _derecha; j > _izquierda; j--)
                    {
                        if (DatosDeEmpleados[j].Codigo > DatosDeEmpleados[j - 1].Codigo)
                        {
                            //Condición cumplida, traspaso de empleados.
                            EmpleadoAux = DatosDeEmpleados[j];
                            DatosDeEmpleados[j] = DatosDeEmpleados[j - 1];
                            DatosDeEmpleados[j - 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosDerecha++;
                        }
                        Preguntas++;
                    }
                    _izquierda++;
                    _derecha--;
                }
                while (_izquierda < _derecha);
            }

            #endregion


            #region Ordenar Por Nombre

            if (rdbNombre.Checked)
            {

                do
                {
                    Comparaciones++;

                    for (int i = _izquierda; i < _derecha; i++)
                    {
                        if (DatosDeEmpleados[i].CompareTo(DatosDeEmpleados[i+1]) < 0)
                        {
                            //Condición cumplida, traspaso de empleados.
                            EmpleadoAux = DatosDeEmpleados[i];
                            DatosDeEmpleados[i] = DatosDeEmpleados[i + 1];
                            DatosDeEmpleados[i + 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosIzquierda++;
                        }
                        Preguntas++;
                    }
                    for (int j = _derecha; j > _izquierda; j--)
                    {
                        if (DatosDeEmpleados[j].CompareTo(DatosDeEmpleados[j - 1]) > 0)
                        {
                            //Condición cumplida, traspaso de empleados.
                            EmpleadoAux = DatosDeEmpleados[j];
                            DatosDeEmpleados[j] = DatosDeEmpleados[j - 1];
                            DatosDeEmpleados[j - 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosDerecha++;
                        }
                        Preguntas++;
                    }
                    _izquierda++;
                    _derecha--;
                }
                while (_izquierda < _derecha);

            }

            #endregion


            #region Ordenar Por Sueldo
            
            if (rdbSueldo.Checked)
            {
                do
                {
                    Comparaciones++;

                    for (int i = _izquierda; i < _derecha; i++)
                    {
                        if (DatosDeEmpleados[i].Sueldo < DatosDeEmpleados[i + 1].Sueldo)
                        {
                            //Condición cumplida, traspaso de empleados.
                            EmpleadoAux = DatosDeEmpleados[i];
                            DatosDeEmpleados[i] = DatosDeEmpleados[i + 1];
                            DatosDeEmpleados[i + 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosIzquierda++;
                        }
                        Preguntas++;
                    }
                    for (int j = _derecha; j > _izquierda; j--)
                    {
                        if (DatosDeEmpleados[j].Sueldo > DatosDeEmpleados[j - 1].Sueldo)
                        {
                            //Condición cumplida, traspaso de empleados.
                            EmpleadoAux = DatosDeEmpleados[j];
                            DatosDeEmpleados[j] = DatosDeEmpleados[j - 1];
                            DatosDeEmpleados[j - 1] = EmpleadoAux;
                            Movimientos++;
                            MovimientosDerecha++;
                        }
                        Preguntas++;
                    }
                    _izquierda++;
                    _derecha--;
                }
                while (_izquierda < _derecha);
            }

            #endregion


            #region Variables Para dar los datos
            txtComp.Text = Comparaciones.ToString();
            txtPreg.Text = Preguntas.ToString();
            txtMovDer.Text = MovimientosDerecha.ToString();
            txtMovIzq.Text = MovimientosIzquierda.ToString();
            #endregion
        }

        #endregion


        private void btnOrdenar_Click(object sender, EventArgs e)
        {
            try
            {
                pbImagen.ImageLocation = null;

                var cronometro = new System.Diagnostics.Stopwatch();
                cronometro.Start();

                #region Ascendente
                if (rdbAsc.Checked)
                {
                    //------------------------------------------------------------------------------------------

                    OrdenarAscendente();

                    cronometro.Stop();
                    TimeSpan tiempoTranscurrido = cronometro.Elapsed;
                    string TiempoTotal = string.Format("{0:00} : {1:00} : {2:00} . {3:00}",
                                                tiempoTranscurrido.Hours,
                                                          tiempoTranscurrido.Minutes,
                                                                    tiempoTranscurrido.Seconds,
                                                                                tiempoTranscurrido.Milliseconds / 10);
                    MessageBox.Show("El Tiempo de Ordenamiento es de: " + "\r" + TiempoTotal);

                    //-------------------------------------------------------------------------------------------

                    cronometro.Reset();

                    cronometro.Start();

                    PintarTabla();

                    cronometro.Stop();
                    TimeSpan tiempoTrans = cronometro.Elapsed;
                    string TiempoTo = string.Format("{0:00} : {1:00} : {2:00} . {3:00}",
                                                tiempoTrans.Hours,
                                                          tiempoTrans.Minutes,
                                                                    tiempoTrans.Seconds,
                                                                                tiempoTrans.Milliseconds / 10);
                    MessageBox.Show("El Tiempo de Mostrar los datos es de: " + "\r" + TiempoTo);

                    pbImagen.ImageLocation = @"C:\Users\Owner\OneDrive\Documentos\UNIVERSIDAD\UNIVERSIDAD 3ER SEMESTRE\ESTRUCTURA DE DATOS\PARCIAL 4\ShakerSort\BurbujaBidireccional_Shaker\Imagenes\ordenado.png";


                    //---------------------------------------------------------------------------------------------
                }

                #endregion


                #region Descendente
                if (rdbDes.Checked)
                {

                    //----------------------------------------------------------------------------------------------

                    OrdenarDescendente();


                    cronometro.Stop();
                    TimeSpan tiempoTranscurrido = cronometro.Elapsed;
                    string TiempoTotal = string.Format("{0:00} : {1:00} : {2:00} . {3:00}",
                                                tiempoTranscurrido.Hours,
                                                          tiempoTranscurrido.Minutes,
                                                                    tiempoTranscurrido.Seconds,
                                                                                tiempoTranscurrido.Milliseconds / 10);

                    MessageBox.Show("El Tiempo de Ordenamiento es de: " + "\r" + TiempoTotal);

                    //----------------------------------------------------------------------------------------------

                    cronometro.Reset();

                    cronometro.Start();

                    PintarTabla();

                    cronometro.Stop();
                    TimeSpan tiempoTrans = cronometro.Elapsed;
                    string TiempoTo = string.Format("{0:00} : {1:00} : {2:00} . {3:00}",
                                                tiempoTrans.Hours,
                                                          tiempoTrans.Minutes,
                                                                    tiempoTrans.Seconds,
                                                                                tiempoTrans.Milliseconds / 10);
                    MessageBox.Show("El Tiempo de Mostrar los datos es de: " + "\r" + TiempoTo);

                    pbImagen.ImageLocation = @"C:\Users\Owner\OneDrive\Documentos\UNIVERSIDAD\UNIVERSIDAD 3ER SEMESTRE\ESTRUCTURA DE DATOS\PARCIAL 4\ShakerSort\BurbujaBidireccional_Shaker\Imagenes\ordenado2.png";

                    //-----------------------------------------------------------------------------------------------
                }

                #endregion


            }
            catch (Exception)
            {
                MessageBox.Show("Favor de Ingresar los datos primeramente");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
