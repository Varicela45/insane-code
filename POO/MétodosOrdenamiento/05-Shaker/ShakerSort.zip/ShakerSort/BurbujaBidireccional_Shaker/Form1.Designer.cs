﻿
namespace BurbujaBidireccional_Shaker
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbxTamaño = new System.Windows.Forms.ComboBox();
            this.lblTamaño = new System.Windows.Forms.Label();
            this.btnRandom = new System.Windows.Forms.Button();
            this.btnOrdenar = new System.Windows.Forms.Button();
            this.gpbOrden = new System.Windows.Forms.GroupBox();
            this.rdbDes = new System.Windows.Forms.RadioButton();
            this.rdbAsc = new System.Windows.Forms.RadioButton();
            this.dgvEmpleados = new System.Windows.Forms.DataGridView();
            this._intCodigo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._strNombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._dblSueldo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gpbDatoAOrd = new System.Windows.Forms.GroupBox();
            this.rdbSueldo = new System.Windows.Forms.RadioButton();
            this.rdbNombre = new System.Windows.Forms.RadioButton();
            this.rdbCodigo = new System.Windows.Forms.RadioButton();
            this.lblPreguntas = new System.Windows.Forms.Label();
            this.lblComparaciones = new System.Windows.Forms.Label();
            this.lblMovIzq = new System.Windows.Forms.Label();
            this.lblMovDer = new System.Windows.Forms.Label();
            this.txtPreg = new System.Windows.Forms.TextBox();
            this.txtComp = new System.Windows.Forms.TextBox();
            this.txtMovIzq = new System.Windows.Forms.TextBox();
            this.txtMovDer = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pbImagen = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.gpbOrden.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).BeginInit();
            this.gpbDatoAOrd.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImagen)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbxTamaño);
            this.groupBox1.Controls.Add(this.lblTamaño);
            this.groupBox1.Controls.Add(this.btnRandom);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(24, 23);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.groupBox1.Size = new System.Drawing.Size(422, 190);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "TAMAÑO DE LISTA";
            // 
            // cbxTamaño
            // 
            this.cbxTamaño.FormattingEnabled = true;
            this.cbxTamaño.Items.AddRange(new object[] {
            "10",
            "100",
            "1000",
            "5000",
            "100000",
            "1000000"});
            this.cbxTamaño.Location = new System.Drawing.Point(20, 104);
            this.cbxTamaño.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.cbxTamaño.MaxDropDownItems = 5;
            this.cbxTamaño.Name = "cbxTamaño";
            this.cbxTamaño.Size = new System.Drawing.Size(136, 45);
            this.cbxTamaño.TabIndex = 12;
            // 
            // lblTamaño
            // 
            this.lblTamaño.AutoSize = true;
            this.lblTamaño.Location = new System.Drawing.Point(12, 52);
            this.lblTamaño.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTamaño.Name = "lblTamaño";
            this.lblTamaño.Size = new System.Drawing.Size(157, 37);
            this.lblTamaño.TabIndex = 11;
            this.lblTamaño.Text = "Números:";
            // 
            // btnRandom
            // 
            this.btnRandom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRandom.Location = new System.Drawing.Point(172, 104);
            this.btnRandom.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(220, 62);
            this.btnRandom.TabIndex = 0;
            this.btnRandom.Text = "Datos Aleatorios";
            this.btnRandom.UseVisualStyleBackColor = true;
            this.btnRandom.Click += new System.EventHandler(this.btnRandom_Click);
            // 
            // btnOrdenar
            // 
            this.btnOrdenar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrdenar.Location = new System.Drawing.Point(24, 633);
            this.btnOrdenar.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnOrdenar.Name = "btnOrdenar";
            this.btnOrdenar.Size = new System.Drawing.Size(392, 106);
            this.btnOrdenar.TabIndex = 13;
            this.btnOrdenar.Text = "ORDENAR";
            this.btnOrdenar.UseVisualStyleBackColor = true;
            this.btnOrdenar.Click += new System.EventHandler(this.btnOrdenar_Click);
            // 
            // gpbOrden
            // 
            this.gpbOrden.Controls.Add(this.rdbDes);
            this.gpbOrden.Controls.Add(this.rdbAsc);
            this.gpbOrden.Location = new System.Drawing.Point(24, 225);
            this.gpbOrden.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.gpbOrden.Name = "gpbOrden";
            this.gpbOrden.Padding = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.gpbOrden.Size = new System.Drawing.Size(392, 192);
            this.gpbOrden.TabIndex = 21;
            this.gpbOrden.TabStop = false;
            this.gpbOrden.Text = "Tipo de Orden";
            // 
            // rdbDes
            // 
            this.rdbDes.AutoSize = true;
            this.rdbDes.Location = new System.Drawing.Point(20, 127);
            this.rdbDes.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.rdbDes.Name = "rdbDes";
            this.rdbDes.Size = new System.Drawing.Size(170, 29);
            this.rdbDes.TabIndex = 1;
            this.rdbDes.Text = "Descendente";
            this.rdbDes.UseVisualStyleBackColor = true;
            // 
            // rdbAsc
            // 
            this.rdbAsc.AutoSize = true;
            this.rdbAsc.Checked = true;
            this.rdbAsc.Location = new System.Drawing.Point(20, 65);
            this.rdbAsc.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.rdbAsc.Name = "rdbAsc";
            this.rdbAsc.Size = new System.Drawing.Size(157, 29);
            this.rdbAsc.TabIndex = 0;
            this.rdbAsc.TabStop = true;
            this.rdbAsc.Text = "Ascendente";
            this.rdbAsc.UseVisualStyleBackColor = true;
            // 
            // dgvEmpleados
            // 
            this.dgvEmpleados.AllowUserToAddRows = false;
            this.dgvEmpleados.AllowUserToDeleteRows = false;
            this.dgvEmpleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpleados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this._intCodigo,
            this._strNombre,
            this._dblSueldo});
            this.dgvEmpleados.Location = new System.Drawing.Point(478, 35);
            this.dgvEmpleados.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.dgvEmpleados.Name = "dgvEmpleados";
            this.dgvEmpleados.ReadOnly = true;
            this.dgvEmpleados.RowHeadersWidth = 82;
            this.dgvEmpleados.Size = new System.Drawing.Size(688, 704);
            this.dgvEmpleados.TabIndex = 22;
            // 
            // _intCodigo
            // 
            this._intCodigo.HeaderText = "Codigo";
            this._intCodigo.MinimumWidth = 10;
            this._intCodigo.Name = "_intCodigo";
            this._intCodigo.ReadOnly = true;
            this._intCodigo.Width = 200;
            // 
            // _strNombre
            // 
            this._strNombre.HeaderText = "Nombre";
            this._strNombre.MinimumWidth = 10;
            this._strNombre.Name = "_strNombre";
            this._strNombre.ReadOnly = true;
            this._strNombre.Width = 200;
            // 
            // _dblSueldo
            // 
            this._dblSueldo.HeaderText = "Sueldo";
            this._dblSueldo.MinimumWidth = 10;
            this._dblSueldo.Name = "_dblSueldo";
            this._dblSueldo.ReadOnly = true;
            this._dblSueldo.Width = 200;
            // 
            // gpbDatoAOrd
            // 
            this.gpbDatoAOrd.Controls.Add(this.rdbSueldo);
            this.gpbDatoAOrd.Controls.Add(this.rdbNombre);
            this.gpbDatoAOrd.Controls.Add(this.rdbCodigo);
            this.gpbDatoAOrd.Location = new System.Drawing.Point(24, 429);
            this.gpbDatoAOrd.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.gpbDatoAOrd.Name = "gpbDatoAOrd";
            this.gpbDatoAOrd.Padding = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.gpbDatoAOrd.Size = new System.Drawing.Size(392, 192);
            this.gpbDatoAOrd.TabIndex = 23;
            this.gpbDatoAOrd.TabStop = false;
            this.gpbDatoAOrd.Text = "Ordenar Por:";
            // 
            // rdbSueldo
            // 
            this.rdbSueldo.AutoSize = true;
            this.rdbSueldo.Location = new System.Drawing.Point(20, 125);
            this.rdbSueldo.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.rdbSueldo.Name = "rdbSueldo";
            this.rdbSueldo.Size = new System.Drawing.Size(110, 29);
            this.rdbSueldo.TabIndex = 2;
            this.rdbSueldo.Text = "Sueldo";
            this.rdbSueldo.UseVisualStyleBackColor = true;
            // 
            // rdbNombre
            // 
            this.rdbNombre.AutoSize = true;
            this.rdbNombre.Location = new System.Drawing.Point(20, 81);
            this.rdbNombre.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.rdbNombre.Name = "rdbNombre";
            this.rdbNombre.Size = new System.Drawing.Size(118, 29);
            this.rdbNombre.TabIndex = 1;
            this.rdbNombre.Text = "Nombre";
            this.rdbNombre.UseVisualStyleBackColor = true;
            // 
            // rdbCodigo
            // 
            this.rdbCodigo.AutoSize = true;
            this.rdbCodigo.Checked = true;
            this.rdbCodigo.Location = new System.Drawing.Point(20, 37);
            this.rdbCodigo.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.rdbCodigo.Name = "rdbCodigo";
            this.rdbCodigo.Size = new System.Drawing.Size(111, 29);
            this.rdbCodigo.TabIndex = 0;
            this.rdbCodigo.TabStop = true;
            this.rdbCodigo.Text = "Codigo";
            this.rdbCodigo.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.rdbCodigo.UseVisualStyleBackColor = true;
            // 
            // lblPreguntas
            // 
            this.lblPreguntas.AutoSize = true;
            this.lblPreguntas.Location = new System.Drawing.Point(30, 54);
            this.lblPreguntas.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPreguntas.Name = "lblPreguntas";
            this.lblPreguntas.Size = new System.Drawing.Size(172, 37);
            this.lblPreguntas.TabIndex = 24;
            this.lblPreguntas.Text = "Preguntas:";
            // 
            // lblComparaciones
            // 
            this.lblComparaciones.AutoSize = true;
            this.lblComparaciones.Location = new System.Drawing.Point(30, 121);
            this.lblComparaciones.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblComparaciones.Name = "lblComparaciones";
            this.lblComparaciones.Size = new System.Drawing.Size(251, 37);
            this.lblComparaciones.TabIndex = 25;
            this.lblComparaciones.Text = "Comparaciones:";
            // 
            // lblMovIzq
            // 
            this.lblMovIzq.AutoSize = true;
            this.lblMovIzq.Location = new System.Drawing.Point(30, 190);
            this.lblMovIzq.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMovIzq.Name = "lblMovIzq";
            this.lblMovIzq.Size = new System.Drawing.Size(291, 37);
            this.lblMovIzq.TabIndex = 26;
            this.lblMovIzq.Text = "Movimientos a Izq: ";
            // 
            // lblMovDer
            // 
            this.lblMovDer.AutoSize = true;
            this.lblMovDer.Location = new System.Drawing.Point(30, 267);
            this.lblMovDer.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblMovDer.Name = "lblMovDer";
            this.lblMovDer.Size = new System.Drawing.Size(300, 37);
            this.lblMovDer.TabIndex = 27;
            this.lblMovDer.Text = "Movimientos a Der: ";
            // 
            // txtPreg
            // 
            this.txtPreg.Enabled = false;
            this.txtPreg.Location = new System.Drawing.Point(214, 48);
            this.txtPreg.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtPreg.Name = "txtPreg";
            this.txtPreg.Size = new System.Drawing.Size(196, 44);
            this.txtPreg.TabIndex = 28;
            // 
            // txtComp
            // 
            this.txtComp.Enabled = false;
            this.txtComp.Location = new System.Drawing.Point(290, 115);
            this.txtComp.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtComp.Name = "txtComp";
            this.txtComp.Size = new System.Drawing.Size(196, 44);
            this.txtComp.TabIndex = 29;
            // 
            // txtMovIzq
            // 
            this.txtMovIzq.Enabled = false;
            this.txtMovIzq.Location = new System.Drawing.Point(330, 185);
            this.txtMovIzq.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtMovIzq.Name = "txtMovIzq";
            this.txtMovIzq.Size = new System.Drawing.Size(196, 44);
            this.txtMovIzq.TabIndex = 30;
            // 
            // txtMovDer
            // 
            this.txtMovDer.Enabled = false;
            this.txtMovDer.Location = new System.Drawing.Point(330, 262);
            this.txtMovDer.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtMovDer.Name = "txtMovDer";
            this.txtMovDer.Size = new System.Drawing.Size(196, 44);
            this.txtMovDer.TabIndex = 31;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblPreguntas);
            this.groupBox2.Controls.Add(this.txtMovDer);
            this.groupBox2.Controls.Add(this.txtPreg);
            this.groupBox2.Controls.Add(this.txtMovIzq);
            this.groupBox2.Controls.Add(this.lblComparaciones);
            this.groupBox2.Controls.Add(this.txtComp);
            this.groupBox2.Controls.Add(this.lblMovIzq);
            this.groupBox2.Controls.Add(this.lblMovDer);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(1198, 35);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.groupBox2.Size = new System.Drawing.Size(670, 333);
            this.groupBox2.TabIndex = 32;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "INFORMACION: ";
            // 
            // pbImagen
            // 
            this.pbImagen.ImageLocation = "";
            this.pbImagen.Location = new System.Drawing.Point(1198, 379);
            this.pbImagen.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.pbImagen.Name = "pbImagen";
            this.pbImagen.Size = new System.Drawing.Size(670, 342);
            this.pbImagen.TabIndex = 33;
            this.pbImagen.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1926, 773);
            this.Controls.Add(this.pbImagen);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gpbDatoAOrd);
            this.Controls.Add(this.dgvEmpleados);
            this.Controls.Add(this.gpbOrden);
            this.Controls.Add(this.btnOrdenar);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Ordenamiento Por Metodo Shaker";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gpbOrden.ResumeLayout(false);
            this.gpbOrden.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).EndInit();
            this.gpbDatoAOrd.ResumeLayout(false);
            this.gpbDatoAOrd.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImagen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbxTamaño;
        private System.Windows.Forms.Label lblTamaño;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.Button btnOrdenar;
        private System.Windows.Forms.GroupBox gpbOrden;
        private System.Windows.Forms.RadioButton rdbDes;
        private System.Windows.Forms.RadioButton rdbAsc;
        private System.Windows.Forms.DataGridView dgvEmpleados;
        private System.Windows.Forms.DataGridViewTextBoxColumn _intCodigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn _strNombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn _dblSueldo;
        private System.Windows.Forms.GroupBox gpbDatoAOrd;
        private System.Windows.Forms.RadioButton rdbSueldo;
        private System.Windows.Forms.RadioButton rdbNombre;
        private System.Windows.Forms.RadioButton rdbCodigo;
        private System.Windows.Forms.Label lblPreguntas;
        private System.Windows.Forms.Label lblComparaciones;
        private System.Windows.Forms.Label lblMovIzq;
        private System.Windows.Forms.Label lblMovDer;
        private System.Windows.Forms.TextBox txtPreg;
        private System.Windows.Forms.TextBox txtComp;
        private System.Windows.Forms.TextBox txtMovIzq;
        private System.Windows.Forms.TextBox txtMovDer;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pbImagen;
    }
}

