﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BurbujaBidireccional_Shaker
{
    public class Empleado: IComparable<Empleado>
    {
        private int _intCodigo;

        public int Codigo
        {
            get { return _intCodigo; }
            set { _intCodigo = value; }
        }

        private string _strNombre;

        public string Nombre
        {
            get { return _strNombre; }
            set { _strNombre = value; }
        }

        private double _dblSueldo;

        public double Sueldo
        {
            get { return _dblSueldo; }
            set { _dblSueldo = value; }
        }

        public int CompareTo(Empleado miEmpleado)
        {
            return this.Nombre.CompareTo(miEmpleado.Nombre);
        }

    }
}
